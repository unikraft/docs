# 02-breaking-stuff

## Challenge Description

You are given an executable.
Run it, find out what it does and find a way to retrieve the flag.

**Hint: All you need to know is in the executable file.**

If everything goes well, the output of the executable will look like this:

```console
$ ./destroy-me
[...]
USoC{...}
```
