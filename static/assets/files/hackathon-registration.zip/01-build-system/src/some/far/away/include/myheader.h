#define PLAIN_SIZE 39
#define KEY_SIZE 11
